# Barakah Mart
Magic Fan has a customer-facing বিস্তারিত দেখুন (details) view with description, features, image and price.
